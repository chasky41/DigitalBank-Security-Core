--
-- PostgreSQL database dump
--

-- Dumped from database version 16.3 (Debian 16.3-1+b1)
-- Dumped by pg_dump version 16.3 (Debian 16.3-1+b1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


--
-- Name: encrypt_card_number(text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.encrypt_card_number(card_number text) RETURNS text
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN encode(encrypt(card_number::bytea, 'CleSecreteExam2026', 'aes'), 'base64');
END;
$$;


ALTER FUNCTION public.encrypt_card_number(card_number text) OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: accounts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.accounts (
    account_id integer NOT NULL,
    customer_id integer NOT NULL,
    account_number character varying(34) NOT NULL,
    account_type character varying(20) NOT NULL,
    balance numeric(15,2) DEFAULT 0.00,
    currency character varying(3) DEFAULT 'EUR'::character varying,
    opened_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    status character varying(20) DEFAULT 'active'::character varying,
    CONSTRAINT accounts_account_type_check CHECK (((account_type)::text = ANY ((ARRAY['checking'::character varying, 'savings'::character varying, 'business'::character varying])::text[]))),
    CONSTRAINT accounts_status_check CHECK (((status)::text = ANY ((ARRAY['active'::character varying, 'frozen'::character varying, 'closed'::character varying])::text[])))
);


ALTER TABLE public.accounts OWNER TO postgres;

--
-- Name: accounts_account_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.accounts_account_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.accounts_account_id_seq OWNER TO postgres;

--
-- Name: accounts_account_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.accounts_account_id_seq OWNED BY public.accounts.account_id;


--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.audit_logs (
    log_id integer NOT NULL,
    user_id integer,
    user_role character varying(50),
    action character varying(100) NOT NULL,
    table_name character varying(50),
    record_id integer,
    ip_address character varying(45),
    "timestamp" timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.audit_logs OWNER TO postgres;

--
-- Name: audit_logs_log_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.audit_logs_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.audit_logs_log_id_seq OWNER TO postgres;

--
-- Name: audit_logs_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.audit_logs_log_id_seq OWNED BY public.audit_logs.log_id;


--
-- Name: cards; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.cards (
    card_id integer NOT NULL,
    account_id integer NOT NULL,
    card_number bytea NOT NULL,
    card_type character varying(20),
    expiry_date date NOT NULL,
    cvv bytea NOT NULL,
    daily_limit numeric(10,2) DEFAULT 1000.00,
    status character varying(20) DEFAULT 'active'::character varying,
    issued_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT cards_card_type_check CHECK (((card_type)::text = ANY ((ARRAY['debit'::character varying, 'credit'::character varying])::text[]))),
    CONSTRAINT cards_status_check CHECK (((status)::text = ANY ((ARRAY['active'::character varying, 'blocked'::character varying, 'expired'::character varying])::text[])))
);


ALTER TABLE public.cards OWNER TO postgres;

--
-- Name: cards_card_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.cards_card_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.cards_card_id_seq OWNER TO postgres;

--
-- Name: cards_card_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.cards_card_id_seq OWNED BY public.cards.card_id;


--
-- Name: customers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.customers (
    customer_id integer NOT NULL,
    email character varying(255) NOT NULL,
    password_hash character varying(255) NOT NULL,
    first_name character varying(100) NOT NULL,
    last_name character varying(100) NOT NULL,
    date_of_birth date,
    phone character varying(20),
    address text,
    city character varying(100),
    postal_code character varying(10),
    country character varying(50) DEFAULT 'France'::character varying,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    last_login timestamp without time zone,
    status character varying(20) DEFAULT 'active'::character varying,
    CONSTRAINT customers_status_check CHECK (((status)::text = ANY ((ARRAY['active'::character varying, 'suspended'::character varying, 'closed'::character varying])::text[])))
);


ALTER TABLE public.customers OWNER TO postgres;

--
-- Name: customers_customer_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.customers_customer_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.customers_customer_id_seq OWNER TO postgres;

--
-- Name: customers_customer_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.customers_customer_id_seq OWNED BY public.customers.customer_id;


--
-- Name: customers_rgpd; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.customers_rgpd AS
 SELECT customer_id,
    'CONFIDENTIEL'::text AS first_name,
    ("substring"((last_name)::text, 1, 1) || '****'::text) AS last_name,
    '***@***.com'::text AS email,
    phone,
    created_at
   FROM public.customers;


ALTER VIEW public.customers_rgpd OWNER TO postgres;

--
-- Name: customers_rgpd_view; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.customers_rgpd_view AS
 SELECT customer_id,
    ("left"((first_name)::text, 1) || '****'::text) AS prenom_masque,
    'NOM_CONFIDENTIEL'::text AS nom_masque,
    '*****@****.com'::text AS email_masque
   FROM public.customers;


ALTER VIEW public.customers_rgpd_view OWNER TO postgres;

--
-- Name: login_attempts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.login_attempts (
    attempt_id integer NOT NULL,
    email character varying(255),
    ip_address character varying(45) NOT NULL,
    user_agent text,
    success boolean NOT NULL,
    failure_reason character varying(100),
    "timestamp" timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.login_attempts OWNER TO postgres;

--
-- Name: login_attempts_attempt_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.login_attempts_attempt_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.login_attempts_attempt_id_seq OWNER TO postgres;

--
-- Name: login_attempts_attempt_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.login_attempts_attempt_id_seq OWNED BY public.login_attempts.attempt_id;


--
-- Name: transactions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.transactions (
    transaction_id integer NOT NULL,
    account_id integer NOT NULL,
    transaction_type character varying(20),
    amount numeric(15,2) NOT NULL,
    currency character varying(3) DEFAULT 'EUR'::character varying,
    merchant_name character varying(255),
    merchant_category character varying(50),
    location character varying(255),
    "timestamp" timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    status character varying(20) DEFAULT 'completed'::character varying,
    is_fraud boolean DEFAULT false,
    fraud_score numeric(3,2),
    CONSTRAINT transactions_status_check CHECK (((status)::text = ANY ((ARRAY['pending'::character varying, 'completed'::character varying, 'failed'::character varying, 'reversed'::character varying])::text[]))),
    CONSTRAINT transactions_transaction_type_check CHECK (((transaction_type)::text = ANY ((ARRAY['deposit'::character varying, 'withdrawal'::character varying, 'transfer'::character varying, 'payment'::character varying, 'fee'::character varying])::text[])))
);


ALTER TABLE public.transactions OWNER TO postgres;

--
-- Name: transactions_transaction_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.transactions_transaction_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.transactions_transaction_id_seq OWNER TO postgres;

--
-- Name: transactions_transaction_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.transactions_transaction_id_seq OWNED BY public.transactions.transaction_id;


--
-- Name: accounts account_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.accounts ALTER COLUMN account_id SET DEFAULT nextval('public.accounts_account_id_seq'::regclass);


--
-- Name: audit_logs log_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.audit_logs ALTER COLUMN log_id SET DEFAULT nextval('public.audit_logs_log_id_seq'::regclass);


--
-- Name: cards card_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cards ALTER COLUMN card_id SET DEFAULT nextval('public.cards_card_id_seq'::regclass);


--
-- Name: customers customer_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customers ALTER COLUMN customer_id SET DEFAULT nextval('public.customers_customer_id_seq'::regclass);


--
-- Name: login_attempts attempt_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.login_attempts ALTER COLUMN attempt_id SET DEFAULT nextval('public.login_attempts_attempt_id_seq'::regclass);


--
-- Name: transactions transaction_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.transactions ALTER COLUMN transaction_id SET DEFAULT nextval('public.transactions_transaction_id_seq'::regclass);


--
-- Data for Name: accounts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.accounts (account_id, customer_id, account_number, account_type, balance, currency, opened_at, status) FROM stdin;
1	1	FR7612345678901234567890123	checking	2500.75	EUR	2026-01-19 18:25:19.129952	active
2	1	FR7612345678901234567890124	savings	15000.00	EUR	2026-01-19 18:25:19.129952	active
3	2	FR7612345678901234567890125	checking	3200.50	EUR	2026-01-19 18:25:19.129952	active
4	3	FR7612345678901234567890126	checking	1800.25	EUR	2026-01-19 18:25:19.129952	active
5	3	FR7612345678901234567890127	business	45000.00	EUR	2026-01-19 18:25:19.129952	active
6	4	FR7612345678901234567890128	checking	950.00	EUR	2026-01-19 18:25:19.129952	active
7	5	FR7612345678901234567890129	checking	5500.80	EUR	2026-01-19 18:25:19.129952	active
8	6	FR7612345678901234567890130	checking	2100.00	EUR	2026-01-19 18:25:19.129952	active
9	6	FR7612345678901234567890131	savings	8000.00	EUR	2026-01-19 18:25:19.129952	active
10	7	FR7612345678901234567890132	checking	3700.50	EUR	2026-01-19 18:25:19.129952	active
11	8	FR7612345678901234567890133	checking	1200.00	EUR	2026-01-19 18:25:19.129952	active
12	9	FR7612345678901234567890134	checking	4500.25	EUR	2026-01-19 18:25:19.129952	active
13	10	FR7612345678901234567890135	savings	12000.00	EUR	2026-01-19 18:25:19.129952	active
\.


--
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.audit_logs (log_id, user_id, user_role, action, table_name, record_id, ip_address, "timestamp") FROM stdin;
\.


--
-- Data for Name: cards; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.cards (card_id, account_id, card_number, card_type, expiry_date, cvv, daily_limit, status, issued_at) FROM stdin;
1	1	\\xc30d040703023d699ded93c3cfd87ed2410153eeec3ec9b8805db0644192e65429f2845c017bbdc73a1190dcba248f82da832230df2b3b571ffc0db17d5b86b05faf11b07515a0018e2ade38bd82a56edd20	debit	2027-12-31	\\xc30d04070302c8225e592bc7a6f267d23401f02eccd0ad02ca1b9b0e1503bce9f8486f9f8baf68bf9881ee72c1716a6a21d3caa990de41509992d7c047deb81e523bdd9ab4	1000.00	active	2026-01-19 18:25:19.145224
2	2	\\xc30d040703021b3ab0fde16e1e086ad24101c3491e81af6365d8e5606e9f3f0a894fa2de2b9e99823968497257fdac21c94f770645521653581accee10d3db189bdf50659137af4197a38894f0c3d3151660	debit	2028-06-30	\\xc30d0407030241da0fc48a1690e47ad23401ea5c4cf71947e571c72518b2444b8607fb10f307ee0e507a979a57eaf0b30a0ac66b864cd3e903b23814602a8b1438a85cf2bb	500.00	active	2026-01-19 18:25:19.145224
3	3	\\xc30d04070302ecede9b9ea851ab366d2410102b4b76e7973430b8e447e0c4a354dd3aa335166781327652c0a2744c05faa2d3d9529bcc105f775a2dd4ca75dfcc65a19d7f844ea7e64d6e6fb3bf10ed55619	debit	2027-09-30	\\xc30d0407030292e3b58417f1284670d234010d90aefff4bb1a5803b80cc9a0cd0458637bf1a66269ef22d2f980eeef527c8b219cf9db71f2f8a462ae6d62bfde57b93dce70	1500.00	active	2026-01-19 18:25:19.145224
4	4	\\xc30d04070302a957c6fa045104ae7bd24101749a45fee75d3b59e784a3168de6f5bfe04f6f2e8a6727e89035cb9464563ae6801b090ba9f783a0f370eb935e254b20bb557111dbdc6a070e8fb4cf15897276	credit	2028-03-31	\\xc30d040703027a04e1a4d764c15c71d2340185fb70c9320e71d25b5be42df1a43c1387ca48e17da3cc5fa8d746063c1c5cad650dfd04dcfacb1120e44eac00e7e7a490688c	3000.00	active	2026-01-19 18:25:19.145224
5	5	\\xc30d0407030249debe36d2b882bb63d24101a03be569596660bf05271755d7da30f06bb93a8481fd4c6c2a4b40645e251483fd6d013c990d1f17de62ed29b5f21fc49b85fc12fe5c35b4f05a9f27f8b9c8f1	debit	2027-11-30	\\xc30d04070302a3bb7ebedf4433b372d234011b949de7edf70c5f254afec4409c507bb2a7f5315ef76835c4636094ba5e830d5a0d8040714cbcdd17b416867e4945f70f0770	2000.00	active	2026-01-19 18:25:19.145224
6	7	\\xc30d04070302b213910ef28d965b60d24101841e5cd869dbfc8b22536e3ab7d91eccc89e199a414a2d9bc989170819b486b5fcdfed4cf46d66e1634387d1964be57fe237da44f0798e9ea0a8c46131209642	debit	2028-01-31	\\xc30d04070302408294a7e83b9ba26ad23401e97558effb907b649e5fd2e434f38f95328ead58796013e4a890aad8d841f51250974a3be1fe1a6bd21097769533ee5db05891	1000.00	active	2026-01-19 18:25:19.145224
7	9	\\xc30d0407030237e33f3f6749d33466d2410160b15ba5ba974496ad3348c6e0944c01d39165013bccaaf792c45e30a9f7e310f7eeb4e41b26d7ecd18a3352862f2b465eec144d297e92efb7cad4a271f9d881	debit	2027-08-31	\\xc30d04070302cfe935285c5e40f360d23401fd014559de08fd69d5be4f4eb9351303b3e1d8d6085c81ed543e831d3cf01d5054aa860209ed09d83ed76973e445cac6d05017	1200.00	active	2026-01-19 18:25:19.145224
8	10	\\xc30d040703029209091f80ada53368d24101329722664e526ff2c8ce281be072676bff443adbc84da00aeefd82c5f51abd7c0115105c549de0cc6534dd16d7b6188b483e09cb0efe4cfd96852908f05c3d4a	credit	2028-05-31	\\xc30d04070302c1ccc952888ece4e6fd234011070fa304bea3100f5a66aeb7612a71bd502dc7cd8cc40976f54cfa9447072c966b1c5230bf5285b0a1695ffe38758552a08e1	2500.00	active	2026-01-19 18:25:19.145224
9	12	\\xc30d04070302ed5859614a105dc76ed241015a5e998e13ba5a12f1eafe6abc3c5f78ad312881bc6d9a730020658056af2a458160158075637ff6057209832000d774cc74c3ad93a06010cb07ff08c3207d78	debit	2027-10-31	\\xc30d04070302081aa9cf85cce5fe63d2340178851722408bdc4dd5cc4408aab4de8fcc38feb6b97fbd863813e7d1c3bc216dc5fbf68ef937ff1df95e284ffc1bfb2471ddde	800.00	active	2026-01-19 18:25:19.145224
10	13	\\xc30d04070302e2a5b4075dc429716dd2410168fff19e0897b60bc8b6569a2861d34f9c9d012525db6c262a38dd40b4e95468ffd0969559fd4bed1919ca5c33df585d93b445e38ea50eea64aacf792ae855ff	debit	2028-02-28	\\xc30d0407030241f2832d72f6afa069d23401c2baededbddd3d23cce291fc8c0372cb257b3dbd47e3ff8da7f873aa6e6c5a5aefad7dda122d569463e6c8428a40cd3b8eb9fb	1500.00	active	2026-01-19 18:25:19.145224
\.


--
-- Data for Name: customers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.customers (customer_id, email, password_hash, first_name, last_name, date_of_birth, phone, address, city, postal_code, country, created_at, last_login, status) FROM stdin;
1	jean.dupont@email.fr	$2b$12$abcdefghijklmnopqrstuvwxyz12345	Jean	Dupont	1985-03-15	0601020304	12 Rue de la Paix	Paris	75001	France	2026-01-19 18:25:19.108918	\N	active
2	marie.martin@email.fr	$2b$12$bcdefghijklmnopqrstuvwxyz123456	Marie	Martin	1990-07-22	0612345678	45 Avenue des Champs	Lyon	69001	France	2026-01-19 18:25:19.108918	\N	active
3	pierre.bernard@email.fr	$2b$12$cdefghijklmnopqrstuvwxyz1234567	Pierre	Bernard	1982-11-08	0623456789	8 Boulevard Victor Hugo	Marseille	13001	France	2026-01-19 18:25:19.108918	\N	active
4	sophie.petit@email.fr	$2b$12$defghijklmnopqrstuvwxyz12345678	Sophie	Petit	1995-02-14	0634567890	3 Rue Gambetta	Toulouse	31000	France	2026-01-19 18:25:19.108918	\N	active
5	luc.durand@email.fr	$2b$12$efghijklmnopqrstuvwxyz123456789	Luc	Durand	1988-09-30	0645678901	15 Allée des Platanes	Nice	06000	France	2026-01-19 18:25:19.108918	\N	active
6	claire.moreau@email.fr	$2b$12$fghijklmnopqrstuvwxyz1234567890	Claire	Moreau	1992-05-18	0656789012	22 Rue de la République	Nantes	44000	France	2026-01-19 18:25:19.108918	\N	active
7	thomas.simon@email.fr	$2b$12$ghijklmnopqrstuvwxyz12345678901	Thomas	Simon	1980-12-25	0667890123	9 Place du Marché	Strasbourg	67000	France	2026-01-19 18:25:19.108918	\N	active
8	emma.laurent@email.fr	$2b$12$hijklmnopqrstuvwxyz123456789012	Emma	Laurent	1997-08-03	0678901234	31 Avenue de la Liberté	Bordeaux	33000	France	2026-01-19 18:25:19.108918	\N	active
9	nicolas.lefebvre@email.fr	$2b$12$ijklmnopqrstuvwxyz1234567890123	Nicolas	Lefebvre	1986-04-12	0689012345	7 Rue Saint-Michel	Lille	59000	France	2026-01-19 18:25:19.108918	\N	active
10	amelie.roux@email.fr	$2b$12$jklmnopqrstuvwxyz12345678901234	Amélie	Roux	1993-10-27	0690123456	18 Cours Lafayette	Rennes	35000	France	2026-01-19 18:25:19.108918	\N	active
\.


--
-- Data for Name: login_attempts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.login_attempts (attempt_id, email, ip_address, user_agent, success, failure_reason, "timestamp") FROM stdin;
\.


--
-- Data for Name: transactions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.transactions (transaction_id, account_id, transaction_type, amount, currency, merchant_name, merchant_category, location, "timestamp", status, is_fraud, fraud_score) FROM stdin;
1	1	payment	-45.50	EUR	Carrefour Market	Groceries	Paris, France	2026-01-19 18:28:09.864825	completed	f	\N
2	1	payment	-120.00	EUR	SNCF	Travel	Lyon, France	2026-01-19 18:28:09.864825	completed	f	\N
3	1	deposit	1500.00	EUR	Salary	Income	Paris, France	2026-01-19 18:28:09.864825	completed	f	\N
4	3	payment	-89.99	EUR	Amazon.fr	Electronics	Online	2026-01-19 18:28:09.864825	completed	f	\N
5	3	payment	-25.30	EUR	Starbucks	Food & Beverage	Paris, France	2026-01-19 18:28:09.864825	completed	f	\N
6	5	transfer	-500.00	EUR	Transfer to savings	Transfer	Online	2026-01-19 18:28:09.864825	completed	f	\N
7	5	payment	-150.00	EUR	EDF	Utilities	Online	2026-01-19 18:28:09.864825	completed	f	\N
8	7	payment	-200.00	EUR	Nike Store	Clothing	Lyon, France	2026-01-19 18:28:09.864825	completed	f	\N
9	9	payment	-75.50	EUR	Auchan	Groceries	Lille, France	2026-01-19 18:28:09.864825	completed	f	\N
10	10	deposit	2000.00	EUR	Salary	Income	Rennes, France	2026-01-19 18:28:09.864825	completed	f	\N
11	1	payment	-12.50	EUR	Boulangerie Paul	Food & Beverage	Paris, France	2026-01-19 18:28:09.864825	completed	f	\N
12	3	payment	-350.00	EUR	FNAC	Electronics	Paris, France	2026-01-19 18:28:09.864825	completed	f	\N
13	4	payment	-80.00	EUR	Shell Station	Fuel	Marseille, France	2026-01-19 18:28:09.864825	completed	f	\N
14	7	payment	-450.00	EUR	Air France	Travel	Online	2026-01-19 18:28:09.864825	completed	f	\N
15	9	withdrawal	-100.00	EUR	ATM Withdrawal	Cash	Lille, France	2026-01-19 18:28:09.864825	completed	f	\N
16	1	payment	-2500.00	EUR	Unknown Merchant	Electronics	Dubai, UAE	2026-01-19 18:28:09.864825	completed	t	\N
17	3	payment	-3500.00	EUR	Luxury Goods Store	Jewelry	Hong Kong	2026-01-19 18:28:09.864825	completed	t	\N
18	5	payment	-1800.00	EUR	Casino Royal	Gambling	Las Vegas, USA	2026-01-19 18:28:09.864825	completed	t	\N
19	7	payment	-4000.00	EUR	Cryptocurrency Exchange	Finance	Online	2026-01-19 18:28:09.864825	completed	t	\N
20	1	payment	-150.00	EUR	Unknown Website	Online Shopping	Unknown	2026-01-19 18:28:09.864825	completed	t	\N
21	3	payment	-2200.00	EUR	Gift Cards Store	Retail	Online	2026-01-19 18:28:09.864825	completed	t	\N
22	5	payment	-1500.00	EUR	International Wire	Transfer	Nigeria	2026-01-19 18:28:09.864825	completed	t	\N
23	9	payment	-800.00	EUR	Bitcoin ATM	Cryptocurrency	Paris, France	2026-01-19 18:28:09.864825	completed	t	\N
24	10	payment	-5000.00	EUR	Wire Transfer	Transfer	Russia	2026-01-19 18:28:09.864825	completed	t	\N
25	1	payment	-200.00	EUR	Suspicious Merchant ABC	Unknown	Online	2026-01-19 18:28:09.864825	completed	t	\N
26	4	payment	-35.00	EUR	McDonald's	Food & Beverage	Marseille, France	2026-01-19 18:28:09.864825	completed	f	\N
27	7	payment	-60.00	EUR	Pharmacie	Health	Strasbourg, France	2026-01-19 18:28:09.864825	completed	f	\N
28	10	payment	-180.00	EUR	H&M	Clothing	Rennes, France	2026-01-19 18:28:09.864825	completed	f	\N
29	12	payment	-95.00	EUR	Cinema Gaumont	Entertainment	Bordeaux, France	2026-01-19 18:28:09.864825	completed	f	\N
30	13	payment	-250.00	EUR	Hotel Ibis	Travel	Nice, France	2026-01-19 18:28:09.864825	completed	f	\N
\.


--
-- Name: accounts_account_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.accounts_account_id_seq', 13, true);


--
-- Name: audit_logs_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.audit_logs_log_id_seq', 1, false);


--
-- Name: cards_card_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.cards_card_id_seq', 10, true);


--
-- Name: customers_customer_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.customers_customer_id_seq', 10, true);


--
-- Name: login_attempts_attempt_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.login_attempts_attempt_id_seq', 1, false);


--
-- Name: transactions_transaction_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.transactions_transaction_id_seq', 30, true);


--
-- Name: accounts accounts_account_number_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.accounts
    ADD CONSTRAINT accounts_account_number_key UNIQUE (account_number);


--
-- Name: accounts accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.accounts
    ADD CONSTRAINT accounts_pkey PRIMARY KEY (account_id);


--
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (log_id);


--
-- Name: cards cards_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cards
    ADD CONSTRAINT cards_pkey PRIMARY KEY (card_id);


--
-- Name: customers customers_email_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT customers_email_key UNIQUE (email);


--
-- Name: customers customers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT customers_pkey PRIMARY KEY (customer_id);


--
-- Name: login_attempts login_attempts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.login_attempts
    ADD CONSTRAINT login_attempts_pkey PRIMARY KEY (attempt_id);


--
-- Name: transactions transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_pkey PRIMARY KEY (transaction_id);


--
-- Name: idx_login_attempts_ip; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_login_attempts_ip ON public.login_attempts USING btree (ip_address);


--
-- Name: idx_login_attempts_timestamp; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_login_attempts_timestamp ON public.login_attempts USING btree ("timestamp");


--
-- Name: idx_transactions_account_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_transactions_account_id ON public.transactions USING btree (account_id);


--
-- Name: idx_transactions_is_fraud; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_transactions_is_fraud ON public.transactions USING btree (is_fraud);


--
-- Name: idx_transactions_timestamp; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_transactions_timestamp ON public.transactions USING btree ("timestamp");


--
-- Name: accounts accounts_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.accounts
    ADD CONSTRAINT accounts_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customers(customer_id) ON DELETE CASCADE;


--
-- Name: cards cards_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cards
    ADD CONSTRAINT cards_account_id_fkey FOREIGN KEY (account_id) REFERENCES public.accounts(account_id) ON DELETE CASCADE;


--
-- Name: transactions transactions_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_account_id_fkey FOREIGN KEY (account_id) REFERENCES public.accounts(account_id) ON DELETE CASCADE;


--
-- Name: TABLE accounts; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT ON TABLE public.accounts TO admin_user;
GRANT SELECT ON TABLE public.accounts TO analyst_user;


--
-- Name: TABLE audit_logs; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT ON TABLE public.audit_logs TO admin_user;
GRANT SELECT ON TABLE public.audit_logs TO analyst_user;


--
-- Name: TABLE cards; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT ON TABLE public.cards TO admin_user;
GRANT SELECT ON TABLE public.cards TO analyst_user;


--
-- Name: TABLE customers; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT ON TABLE public.customers TO admin_user;
GRANT SELECT ON TABLE public.customers TO analyst_user;


--
-- Name: TABLE customers_rgpd; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT ON TABLE public.customers_rgpd TO admin_user;
GRANT SELECT ON TABLE public.customers_rgpd TO analyst_user;


--
-- Name: TABLE login_attempts; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT ON TABLE public.login_attempts TO admin_user;
GRANT SELECT ON TABLE public.login_attempts TO analyst_user;


--
-- Name: TABLE transactions; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT ON TABLE public.transactions TO admin_user;
GRANT SELECT ON TABLE public.transactions TO analyst_user;


--
-- PostgreSQL database dump complete
--

